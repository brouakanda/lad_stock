package com.inphb.icgl.stocks.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton de connexion à la base de données MySQL.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class DatabaseConnection {

    private static final String URL      = "jdbc:mysql://localhost:3306/stockmanager_ci?useSSL=false&serverTimezone=UTC&characterEncoding=utf8&allowPublicKeyRetrieval=true";
    private static final String USER     = "root";
    private static final String PASSWORD = "";

    private static Connection instance = null;

    private DatabaseConnection() {}

    /**
     * Retourne la connexion unique (Singleton).
     * Si fermée ou nulle, en crée une nouvelle.
     */
    public static Connection getInstance() throws SQLException {
        if (instance == null || instance.isClosed()) {
            instance = DriverManager.getConnection(URL, USER, PASSWORD);
        }
        return instance;
    }

    /**
     * Ferme la connexion proprement.
     */
    public static void closeConnection() {
        if (instance != null) {
            try {
                instance.close();
                instance = null;
            } catch (SQLException e) {
                System.err.println("Erreur fermeture connexion : " + e.getMessage());
            }
        }
    }

    /**
     * Teste si la connexion est disponible.
     */
    public static boolean testConnection() {
        try {
            Connection conn = getInstance();
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}

package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Fournisseur;
import javafx.collections.ObservableList;

/**
 * Interface Repository pour les fournisseurs.
 * Auteur : LENAUD SOKONI NADIA
 */
public interface IFournisseurRepository {
    boolean save(Fournisseur f);
    boolean update(Fournisseur f);
    boolean delete(int id);
    Fournisseur findById(int id);
    ObservableList<Fournisseur> findAll(int page, int pageSize);
    ObservableList<Fournisseur> findAllNoPagination();
    int countAll();
    ObservableList<Fournisseur> search(String motCle, int page, int size);
    int countSearch(String motCle);
    boolean hasProducts(int id);
}

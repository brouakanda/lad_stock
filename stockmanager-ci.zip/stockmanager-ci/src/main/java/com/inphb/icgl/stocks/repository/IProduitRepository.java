package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Produit;
import javafx.collections.ObservableList;

/**
 * Interface Repository pour les produits.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public interface IProduitRepository {
    boolean save(Produit p);
    boolean update(Produit p);
    boolean delete(int id);
    Produit findById(int id);
    ObservableList<Produit> findAll(int page, int pageSize);
    ObservableList<Produit> findAllNoPagination();
    int countAll();
    ObservableList<Produit> search(String motCle, int page, int size);
    int countSearch(String motCle);
    ObservableList<Produit> findEnAlerte();
    int countEnAlerte();
    double getValeurTotaleStock();
}

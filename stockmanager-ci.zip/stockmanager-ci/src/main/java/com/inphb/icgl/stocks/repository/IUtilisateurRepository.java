package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Utilisateur;
import javafx.collections.ObservableList;

/**
 * Interface Repository pour les utilisateurs.
 * Auteur : DOUMBIA KARIDJATOU
 */
public interface IUtilisateurRepository {
    boolean save(Utilisateur u);
    boolean update(Utilisateur u);
    boolean delete(int id);
    boolean desactiver(int id);
    Utilisateur findById(int id);
    Utilisateur findByLogin(String login);
    Utilisateur authenticate(String login, String passwordHash);
    ObservableList<Utilisateur> findAll(int page, int pageSize);
    int countAll();
}

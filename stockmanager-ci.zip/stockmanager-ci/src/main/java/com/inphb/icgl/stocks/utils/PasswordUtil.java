package com.inphb.icgl.stocks.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utilitaire de hashage des mots de passe (SHA-256).
 * Auteur : LENAUD SOKONI NADIA
 */
public class PasswordUtil {

    private PasswordUtil() {}

    /**
     * Hashe un mot de passe en SHA-256 (64 caractères hexadécimaux).
     * Équivalent à MySQL SHA2(mdp, 256).
     */
    public static String hash(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(password.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            // Fallback : hashCode en hex (acceptable selon le cahier des charges)
            return Integer.toHexString(password.hashCode());
        }
    }

    /**
     * Vérifie si un mot de passe correspond à son hash stocké.
     */
    public static boolean verify(String password, String storedHash) {
        return hash(password).equals(storedHash);
    }
}

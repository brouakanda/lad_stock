package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Mouvement;
import javafx.collections.ObservableList;

/**
 * Interface Repository pour les mouvements de stock.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public interface IMouvementRepository {
    boolean save(Mouvement m);
    Mouvement findById(int id);
    ObservableList<Mouvement> findAll(int page, int pageSize);
    int countAll();
    ObservableList<Mouvement> search(String motCle, String dateDebut, String dateFin, int page, int size);
    int countSearch(String motCle, String dateDebut, String dateFin);
    int countMouvementsDuJour();
}

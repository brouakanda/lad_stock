package com.inphb.icgl.stocks.model;

import javafx.beans.property.*;

/**
 * Modèle Categorie avec Properties JavaFX.
 * Auteur : DOUMBIA KARIDJATOU
 */
public class Categorie {

    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty libelle = new SimpleStringProperty();
    private final StringProperty description = new SimpleStringProperty();

    public Categorie() {}

    public Categorie(int id, String libelle, String description) {
        setId(id);
        setLibelle(libelle);
        setDescription(description);
    }

    public int getId() { return id.get(); }
    public void setId(int v) { id.set(v); }
    public IntegerProperty idProperty() { return id; }

    public String getLibelle() { return libelle.get(); }
    public void setLibelle(String v) { libelle.set(v); }
    public StringProperty libelleProperty() { return libelle; }

    public String getDescription() { return description.get(); }
    public void setDescription(String v) { description.set(v); }
    public StringProperty descriptionProperty() { return description; }

    @Override
    public String toString() { return getLibelle(); }
}

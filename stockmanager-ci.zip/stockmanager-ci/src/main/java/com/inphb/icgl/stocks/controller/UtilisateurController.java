package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.UtilisateurDAO;
import com.inphb.icgl.stocks.model.Utilisateur;
import com.inphb.icgl.stocks.utils.AlertUtil;
import com.inphb.icgl.stocks.utils.PasswordUtil;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Contrôleur du module Utilisateurs (réservé aux ADMIN).
 * Auteur : DOUMBIA KARIDJATOU
 */
public class UtilisateurController {

    @FXML private TableView<Utilisateur> tableUtilisateurs;
    @FXML private TableColumn<Utilisateur, Integer> colId;
    @FXML private TableColumn<Utilisateur, String> colNom;
    @FXML private TableColumn<Utilisateur, String> colLogin;
    @FXML private TableColumn<Utilisateur, String> colRole;
    @FXML private TableColumn<Utilisateur, Boolean> colActif;

    @FXML private TextField txtNomComplet;
    @FXML private TextField txtLogin;
    @FXML private PasswordField txtPassword;
    @FXML private PasswordField txtConfirmPassword;
    @FXML private ComboBox<String> cbRole;
    @FXML private CheckBox chkActif;

    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnDesactiver;
    @FXML private Button btnNouveau;
    @FXML private Label lblStatut;
    @FXML private Label lblPage;
    @FXML private Button btnPrecedent;
    @FXML private Button btnSuivant;

    private final UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
    private Utilisateur utilisateurSelectionne = null;
    private int pageCourante = 1;
    private static final int PAGE_SIZE = 15;
    private int totalPages = 1;

    @FXML
    public void initialize() {
        if (!SessionManager.isAdmin()) {
            AlertUtil.showWarning("Accès refusé", "Module réservé aux administrateurs.");
            return;
        }
        configurerColonnes();
        configurerCombos();
        configurerSelection();
        chargerDonnees();
        modeAjout();
    }

    private void configurerColonnes() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nomComplet"));
        colLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colActif.setCellValueFactory(new PropertyValueFactory<>("actif"));

        colActif.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Boolean actif, boolean empty) {
                super.updateItem(actif, empty);
                if (empty || actif == null) { setText(null); setStyle(""); }
                else if (actif) { setText("✔ Actif"); setStyle("-fx-text-fill: #1b5e20; -fx-font-weight: bold;"); }
                else { setText("✘ Inactif"); setStyle("-fx-text-fill: #b71c1c; -fx-font-weight: bold;"); }
            }
        });

        colRole.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String role, boolean empty) {
                super.updateItem(role, empty);
                if (empty || role == null) { setText(null); setStyle(""); }
                else if ("ADMIN".equals(role)) { setText("👑 ADMIN"); setStyle("-fx-text-fill: #f39c12; -fx-font-weight: bold;"); }
                else { setText("👤 GESTIONNAIRE"); setStyle("-fx-text-fill: #2980b9;"); }
            }
        });
    }

    private void configurerCombos() {
        cbRole.setItems(FXCollections.observableArrayList("ADMIN", "GESTIONNAIRE"));
        cbRole.setValue("GESTIONNAIRE");
        if (chkActif != null) chkActif.setSelected(true);
    }

    private void configurerSelection() {
        tableUtilisateurs.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                utilisateurSelectionne = selected;
                txtNomComplet.setText(selected.getNomComplet());
                txtLogin.setText(selected.getLogin());
                txtPassword.clear();
                txtConfirmPassword.clear();
                cbRole.setValue(selected.getRole());
                if (chkActif != null) chkActif.setSelected(selected.isActif());
                btnModifier.setDisable(false);
                btnDesactiver.setDisable(selected.getId() == SessionManager.getUserId());
            }
        });
    }

    private void chargerDonnees() {
        ObservableList<Utilisateur> data = utilisateurDAO.findAll(pageCourante, PAGE_SIZE);
        int total = utilisateurDAO.countAll();
        tableUtilisateurs.setItems(data);
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        lblPage.setText("Page " + pageCourante + " / " + totalPages + "  —  " + total + " utilisateur(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { if (pageCourante > 1) { pageCourante--; chargerDonnees(); } }
    @FXML private void handleSuivant()   { if (pageCourante < totalPages) { pageCourante++; chargerDonnees(); } }

    @FXML
    private void handleAjouter() {
        if (!validerFormulaire(true)) return;
        Utilisateur u = new Utilisateur();
        u.setNomComplet(txtNomComplet.getText().trim());
        u.setLogin(txtLogin.getText().trim());
        u.setMotDePasse(PasswordUtil.hash(txtPassword.getText()));
        u.setRole(cbRole.getValue());
        u.setActif(chkActif != null && chkActif.isSelected());

        if (utilisateurDAO.save(u)) {
            afficherStatut("✔ Utilisateur créé avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible de créer l'utilisateur (login déjà existant ?)");
        }
    }

    @FXML
    private void handleModifier() {
        if (utilisateurSelectionne == null || !validerFormulaire(false)) return;
        utilisateurSelectionne.setNomComplet(txtNomComplet.getText().trim());
        utilisateurSelectionne.setLogin(txtLogin.getText().trim());
        utilisateurSelectionne.setRole(cbRole.getValue());
        utilisateurSelectionne.setActif(chkActif != null && chkActif.isSelected());

        if (utilisateurDAO.update(utilisateurSelectionne)) {
            if (!txtPassword.getText().isEmpty()) {
                utilisateurDAO.updatePassword(utilisateurSelectionne.getId(),
                        PasswordUtil.hash(txtPassword.getText()));
            }
            afficherStatut("✔ Utilisateur modifié avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible de modifier l'utilisateur.");
        }
    }

    @FXML
    private void handleDesactiver() {
        if (utilisateurSelectionne == null) return;
        if (utilisateurSelectionne.getId() == SessionManager.getUserId()) {
            AlertUtil.showWarning("Action impossible", "Vous ne pouvez pas vous désactiver vous-même.");
            return;
        }
        boolean confirm = AlertUtil.showConfirmation("Confirmer",
                "Désactiver l'utilisateur « " + utilisateurSelectionne.getLogin() + " » ?");
        if (confirm) {
            if (utilisateurDAO.desactiver(utilisateurSelectionne.getId())) {
                afficherStatut("✔ Utilisateur désactivé.");
                modeAjout();
                chargerDonnees();
            } else {
                AlertUtil.showError("Erreur", "Impossible de désactiver l'utilisateur.");
            }
        }
    }

    @FXML private void handleNouveau() { modeAjout(); }

    private boolean validerFormulaire(boolean mdpObligatoire) {
        if (txtNomComplet.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le nom complet est obligatoire."); return false;
        }
        if (txtLogin.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le login est obligatoire."); return false;
        }
        if (mdpObligatoire && txtPassword.getText().isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le mot de passe est obligatoire."); return false;
        }
        if (!txtPassword.getText().isEmpty() && !txtPassword.getText().equals(txtConfirmPassword.getText())) {
            AlertUtil.showWarning("Mots de passe différents", "Les deux mots de passe ne correspondent pas."); return false;
        }
        return true;
    }

    private void modeAjout() {
        utilisateurSelectionne = null;
        txtNomComplet.clear(); txtLogin.clear();
        txtPassword.clear(); txtConfirmPassword.clear();
        cbRole.setValue("GESTIONNAIRE");
        if (chkActif != null) chkActif.setSelected(true);
        btnModifier.setDisable(true);
        btnDesactiver.setDisable(true);
        tableUtilisateurs.getSelectionModel().clearSelection();
        lblStatut.setText("");
    }

    private void afficherStatut(String msg) { lblStatut.setText(msg); }
}

package com.inphb.icgl.stocks.model;

import javafx.beans.property.*;

/**
 * Modèle Utilisateur avec Properties JavaFX.
 * Auteur : DOUMBIA KARIDJATOU
 */
public class Utilisateur {

    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty nomComplet = new SimpleStringProperty();
    private final StringProperty login = new SimpleStringProperty();
    private final StringProperty motDePasse = new SimpleStringProperty();
    private final StringProperty role = new SimpleStringProperty();
    private final BooleanProperty actif = new SimpleBooleanProperty();

    public Utilisateur() {}

    public Utilisateur(int id, String nomComplet, String login, String motDePasse, String role, boolean actif) {
        setId(id);
        setNomComplet(nomComplet);
        setLogin(login);
        setMotDePasse(motDePasse);
        setRole(role);
        setActif(actif);
    }

    // ── Getters / Setters ──────────────────────────────────────────
    public int getId() { return id.get(); }
    public void setId(int id) { this.id.set(id); }
    public IntegerProperty idProperty() { return id; }

    public String getNomComplet() { return nomComplet.get(); }
    public void setNomComplet(String v) { nomComplet.set(v); }
    public StringProperty nomCompletProperty() { return nomComplet; }

    public String getLogin() { return login.get(); }
    public void setLogin(String v) { login.set(v); }
    public StringProperty loginProperty() { return login; }

    public String getMotDePasse() { return motDePasse.get(); }
    public void setMotDePasse(String v) { motDePasse.set(v); }
    public StringProperty motDePasseProperty() { return motDePasse; }

    public String getRole() { return role.get(); }
    public void setRole(String v) { role.set(v); }
    public StringProperty roleProperty() { return role; }

    public boolean isActif() { return actif.get(); }
    public void setActif(boolean v) { actif.set(v); }
    public BooleanProperty actifProperty() { return actif; }

    @Override
    public String toString() { return getNomComplet(); }
}

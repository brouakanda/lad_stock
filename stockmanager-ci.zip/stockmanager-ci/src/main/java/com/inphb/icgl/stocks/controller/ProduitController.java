package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.CategorieDAO;
import com.inphb.icgl.stocks.dao.FournisseurDAO;
import com.inphb.icgl.stocks.dao.ProduitDAO;
import com.inphb.icgl.stocks.model.Categorie;
import com.inphb.icgl.stocks.model.Fournisseur;
import com.inphb.icgl.stocks.model.Produit;
import com.inphb.icgl.stocks.utils.AlertUtil;
import com.inphb.icgl.stocks.utils.ExportUtil;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.List;

/**
 * Contrôleur du module Produits (module central).
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class ProduitController {

    @FXML private TableView<Produit> tableProduits;
    @FXML private TableColumn<Produit, Integer> colId;
    @FXML private TableColumn<Produit, String> colReference;
    @FXML private TableColumn<Produit, String> colDesignation;
    @FXML private TableColumn<Produit, String> colCategorie;
    @FXML private TableColumn<Produit, String> colFournisseur;
    @FXML private TableColumn<Produit, Double> colPrix;
    @FXML private TableColumn<Produit, Integer> colQuantite;
    @FXML private TableColumn<Produit, Integer> colStockMin;
    @FXML private TableColumn<Produit, String> colUnite;

    @FXML private TextField txtReference;
    @FXML private TextField txtDesignation;
    @FXML private ComboBox<Categorie> cbCategorie;
    @FXML private ComboBox<Fournisseur> cbFournisseur;
    @FXML private TextField txtPrix;
    @FXML private TextField txtQuantite;
    @FXML private TextField txtStockMin;
    @FXML private ComboBox<String> cbUnite;
    @FXML private TextField txtRecherche;

    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;
    @FXML private Button btnExporterXLSX;
    @FXML private Button btnExporterPDF;
    @FXML private Label lblStatut;
    @FXML private Label lblPage;
    @FXML private Button btnPrecedent;
    @FXML private Button btnSuivant;
    @FXML private Label lblAlertCount;

    private final ProduitDAO produitDAO = new ProduitDAO();
    private final CategorieDAO categorieDAO = new CategorieDAO();
    private final FournisseurDAO fournisseurDAO = new FournisseurDAO();
    private Produit produitSelectionne = null;
    private int pageCourante = 1;
    private static final int PAGE_SIZE = 15;
    private int totalPages = 1;
    private String motCleRecherche = "";

    @FXML
    public void initialize() {
        configurerColonnes();
        configurerAlerteVisuelles();
        configurerComboBoxes();
        configurerSelection();
        configurerRecherche();
        chargerDonnees();
        modeAjout();
    }

    private void configurerColonnes() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colReference.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colDesignation.setCellValueFactory(new PropertyValueFactory<>("designation"));
        colCategorie.setCellValueFactory(new PropertyValueFactory<>("nomCategorie"));
        colFournisseur.setCellValueFactory(new PropertyValueFactory<>("nomFournisseur"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prixUnitaire"));
        colQuantite.setCellValueFactory(new PropertyValueFactory<>("quantiteStock"));
        colStockMin.setCellValueFactory(new PropertyValueFactory<>("stockMinimum"));
        colUnite.setCellValueFactory(new PropertyValueFactory<>("unite"));

        // Formater le prix
        colPrix.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Double prix, boolean empty) {
                super.updateItem(prix, empty);
                setText(empty || prix == null ? null : String.format("%,.0f FCFA", prix));
            }
        });
    }

    private void configurerAlerteVisuelles() {
        tableProduits.setRowFactory(tv -> new TableRow<Produit>() {
            @Override
            protected void updateItem(Produit p, boolean empty) {
                super.updateItem(p, empty);
                if (p == null || empty) {
                    setStyle("");
                } else if (p.getQuantiteStock() <= p.getStockMinimum()) {
                    setStyle("-fx-background-color: #FFEBEE; -fx-border-color: #FFCDD2;");
                } else {
                    setStyle("");
                }
            }
        });
    }

    private void configurerComboBoxes() {
        cbCategorie.setItems(categorieDAO.findAllNoPagination());
        cbFournisseur.setItems(fournisseurDAO.findAllNoPagination());
        cbUnite.getItems().addAll("pièce", "kg", "litre", "sac", "carton", "boîte",
                                   "bidon", "rouleau", "mètre", "tonne", "palette");
        cbUnite.setValue("pièce");
    }

    private void configurerSelection() {
        tableProduits.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                produitSelectionne = selected;
                remplirFormulaire(selected);
                btnModifier.setDisable(false);
                btnSupprimer.setDisable(false);
            }
        });
    }

    private void remplirFormulaire(Produit p) {
        txtReference.setText(p.getReference());
        txtDesignation.setText(p.getDesignation());
        txtPrix.setText(String.valueOf(p.getPrixUnitaire()));
        txtQuantite.setText(String.valueOf(p.getQuantiteStock()));
        txtStockMin.setText(String.valueOf(p.getStockMinimum()));
        cbUnite.setValue(p.getUnite());
        // Sélectionner la catégorie
        cbCategorie.getItems().stream()
                .filter(c -> c.getId() == p.getIdCategorie())
                .findFirst().ifPresent(cbCategorie::setValue);
        // Sélectionner le fournisseur
        cbFournisseur.getItems().stream()
                .filter(f -> f.getId() == p.getIdFournisseur())
                .findFirst().ifPresent(cbFournisseur::setValue);
    }

    private void configurerRecherche() {
        txtRecherche.textProperty().addListener((obs, old, val) -> {
            motCleRecherche = val.trim();
            pageCourante = 1;
            chargerDonnees();
        });
    }

    private void chargerDonnees() {
        ObservableList<Produit> data;
        int total;
        if (motCleRecherche.isEmpty()) {
            data = produitDAO.findAll(pageCourante, PAGE_SIZE);
            total = produitDAO.countAll();
        } else {
            data = produitDAO.search(motCleRecherche, pageCourante, PAGE_SIZE);
            total = produitDAO.countSearch(motCleRecherche);
        }
        tableProduits.setItems(data);
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        lblPage.setText("Page " + pageCourante + " / " + totalPages + "  —  " + total + " produit(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);

        int nbAlertes = produitDAO.countEnAlerte();
        if (lblAlertCount != null) {
            lblAlertCount.setText(nbAlertes + " en alerte ⚠");
            lblAlertCount.setStyle(nbAlertes > 0 ?
                    "-fx-text-fill: #c0392b; -fx-font-weight: bold;" :
                    "-fx-text-fill: #27ae60;");
        }
    }

    @FXML private void handlePrecedent() { if (pageCourante > 1) { pageCourante--; chargerDonnees(); } }
    @FXML private void handleSuivant()   { if (pageCourante < totalPages) { pageCourante++; chargerDonnees(); } }

    @FXML
    private void handleAjouter() {
        if (!validerFormulaire()) return;
        Produit p = construireProduit(0);
        if (produitDAO.save(p)) {
            afficherStatut("✔ Produit « " + p.getDesignation() + " » ajouté.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible d'ajouter le produit (référence déjà existante ?)");
        }
    }

    @FXML
    private void handleModifier() {
        if (produitSelectionne == null || !validerFormulaire()) return;
        Produit p = construireProduit(produitSelectionne.getId());
        if (produitDAO.update(p)) {
            afficherStatut("✔ Produit modifié avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible de modifier le produit.");
        }
    }

    @FXML
    private void handleSupprimer() {
        if (produitSelectionne == null) return;
        boolean confirm = AlertUtil.showConfirmation("Confirmer",
                "Supprimer le produit « " + produitSelectionne.getDesignation() + " » ?\n" +
                "Ses mouvements seront également supprimés.");
        if (confirm) {
            if (produitDAO.delete(produitSelectionne.getId())) {
                afficherStatut("✔ Produit supprimé.");
                modeAjout();
                chargerDonnees();
            } else {
                AlertUtil.showError("Erreur", "Impossible de supprimer le produit.");
            }
        }
    }

    @FXML
    private void handleExporterXLSX() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Enregistrer le fichier Excel");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier Excel", "*.xlsx"));
        fc.setInitialFileName("produits_stock.xlsx");
        Stage stage = (Stage) btnExporterXLSX.getScene().getWindow();
        File fichier = fc.showSaveDialog(stage);
        if (fichier != null) {
            try {
                List<Produit> tous = produitDAO.findAllNoPagination();
                ExportUtil.exporterXLSX(tous, fichier);
                AlertUtil.showInfo("Export réussi", "Fichier Excel exporté :\n" + fichier.getAbsolutePath());
                afficherStatut("✔ Export XLSX réussi : " + fichier.getName());
            } catch (Exception e) {
                AlertUtil.showError("Erreur export", e.getMessage());
            }
        }
    }

    @FXML
    private void handleExporterPDF() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Enregistrer le fichier PDF");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier PDF", "*.pdf"));
        fc.setInitialFileName("produits_stock.pdf");
        Stage stage = (Stage) btnExporterPDF.getScene().getWindow();
        File fichier = fc.showSaveDialog(stage);
        if (fichier != null) {
            try {
                List<Produit> tous = produitDAO.findAllNoPagination();
                ExportUtil.exporterPDF(tous, fichier);
                AlertUtil.showInfo("Export réussi", "Fichier PDF exporté :\n" + fichier.getAbsolutePath());
                afficherStatut("✔ Export PDF réussi : " + fichier.getName());
            } catch (Exception e) {
                AlertUtil.showError("Erreur export", e.getMessage());
            }
        }
    }

    @FXML private void handleNouveau() { modeAjout(); }

    private boolean validerFormulaire() {
        if (txtReference.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Champ requis", "La référence est obligatoire.");
            return false;
        }
        if (txtDesignation.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Champ requis", "La désignation est obligatoire.");
            return false;
        }
        try {
            double prix = Double.parseDouble(txtPrix.getText().trim());
            if (prix < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            AlertUtil.showWarning("Valeur invalide", "Le prix doit être un nombre positif.");
            return false;
        }
        try {
            int qte = Integer.parseInt(txtQuantite.getText().trim());
            if (qte < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            AlertUtil.showWarning("Valeur invalide", "La quantité doit être un entier positif.");
            return false;
        }
        try {
            int min = Integer.parseInt(txtStockMin.getText().trim());
            if (min < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            AlertUtil.showWarning("Valeur invalide", "Le stock minimum doit être un entier positif.");
            return false;
        }
        return true;
    }

    private Produit construireProduit(int id) {
        Produit p = new Produit();
        p.setId(id);
        p.setReference(txtReference.getText().trim());
        p.setDesignation(txtDesignation.getText().trim());
        p.setIdCategorie(cbCategorie.getValue() != null ? cbCategorie.getValue().getId() : 0);
        p.setIdFournisseur(cbFournisseur.getValue() != null ? cbFournisseur.getValue().getId() : 0);
        p.setPrixUnitaire(Double.parseDouble(txtPrix.getText().trim()));
        p.setQuantiteStock(Integer.parseInt(txtQuantite.getText().trim()));
        p.setStockMinimum(Integer.parseInt(txtStockMin.getText().trim()));
        p.setUnite(cbUnite.getValue() != null ? cbUnite.getValue() : "pièce");
        return p;
    }

    private void modeAjout() {
        produitSelectionne = null;
        txtReference.clear(); txtDesignation.clear();
        txtPrix.clear(); txtQuantite.clear(); txtStockMin.clear();
        cbCategorie.setValue(null); cbFournisseur.setValue(null);
        cbUnite.setValue("pièce");
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
        tableProduits.getSelectionModel().clearSelection();
        lblStatut.setText("");
    }

    private void afficherStatut(String msg) { lblStatut.setText(msg); }
}

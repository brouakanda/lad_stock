package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Fournisseur;
import com.inphb.icgl.stocks.repository.IFournisseurRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

/**
 * DAO pour les fournisseurs — implémentation SQL avec PreparedStatement.
 * Auteur : DOUMBIA KARIDJATOU
 */
public class FournisseurDAO implements IFournisseurRepository {

    @Override
    public boolean save(Fournisseur f) {
        String sql = "INSERT INTO fournisseurs (nom, telephone, email, adresse, ville) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, f.getNom());
            ps.setString(2, f.getTelephone());
            ps.setString(3, f.getEmail());
            ps.setString(4, f.getAdresse());
            ps.setString(5, f.getVille());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.save : " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Fournisseur f) {
        String sql = "UPDATE fournisseurs SET nom=?, telephone=?, email=?, adresse=?, ville=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, f.getNom());
            ps.setString(2, f.getTelephone());
            ps.setString(3, f.getEmail());
            ps.setString(4, f.getAdresse());
            ps.setString(5, f.getVille());
            ps.setInt(6, f.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.update : " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM fournisseurs WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.delete : " + e.getMessage());
            return false;
        }
    }

    @Override
    public Fournisseur findById(int id) {
        String sql = "SELECT * FROM fournisseurs WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.findById : " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Fournisseur> findAll(int page, int pageSize) {
        ObservableList<Fournisseur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM fournisseurs ORDER BY nom LIMIT ? OFFSET ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.findAll : " + e.getMessage());
        }
        return list;
    }

    @Override
    public ObservableList<Fournisseur> findAllNoPagination() {
        ObservableList<Fournisseur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM fournisseurs ORDER BY nom";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.findAllNoPagination : " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM fournisseurs";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.countAll : " + e.getMessage());
        }
        return 0;
    }

    @Override
    public ObservableList<Fournisseur> search(String motCle, int page, int size) {
        ObservableList<Fournisseur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM fournisseurs WHERE nom LIKE ? OR telephone LIKE ? ORDER BY nom LIMIT ? OFFSET ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + motCle + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setInt(3, size);
            ps.setInt(4, (page - 1) * size);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.search : " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countSearch(String motCle) {
        String sql = "SELECT COUNT(*) FROM fournisseurs WHERE nom LIKE ? OR telephone LIKE ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + motCle + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.countSearch : " + e.getMessage());
        }
        return 0;
    }

    @Override
    public boolean hasProducts(int id) {
        String sql = "SELECT COUNT(*) FROM produits WHERE id_fournisseur = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("FournisseurDAO.hasProducts : " + e.getMessage());
        }
        return false;
    }

    private Fournisseur map(ResultSet rs) throws SQLException {
        return new Fournisseur(
                rs.getInt("id"),
                rs.getString("nom"),
                rs.getString("telephone"),
                rs.getString("email"),
                rs.getString("adresse"),
                rs.getString("ville")
        );
    }
}

package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Mouvement;
import com.inphb.icgl.stocks.repository.IMouvementRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * DAO pour les mouvements de stock.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class MouvementDAO implements IMouvementRepository {

    private static final String SELECT_BASE =
            "SELECT m.*, p.designation AS nom_produit, u.nom_complet AS nom_utilisateur " +
            "FROM mouvements m " +
            "LEFT JOIN produits p ON m.id_produit = p.id " +
            "LEFT JOIN utilisateurs u ON m.id_utilisateur = u.id ";

    @Override
    public boolean save(Mouvement m) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getInstance();
            conn.setAutoCommit(false);

            // 1. Insérer le mouvement
            String sqlInsert = "INSERT INTO mouvements (id_produit, type_mouvement, quantite, motif, id_utilisateur) VALUES (?,?,?,?,?)";
            try (PreparedStatement ps = conn.prepareStatement(sqlInsert)) {
                ps.setInt(1, m.getIdProduit());
                ps.setString(2, m.getTypeMouvement());
                ps.setInt(3, m.getQuantite());
                ps.setString(4, m.getMotif());
                if (m.getIdUtilisateur() > 0) ps.setInt(5, m.getIdUtilisateur());
                else ps.setNull(5, Types.INTEGER);
                ps.executeUpdate();
            }

            // 2. Mettre à jour quantite_stock dans produits
            String sqlUpdate;
            if ("ENTREE".equals(m.getTypeMouvement())) {
                sqlUpdate = "UPDATE produits SET quantite_stock = quantite_stock + ? WHERE id = ?";
            } else {
                sqlUpdate = "UPDATE produits SET quantite_stock = quantite_stock - ? WHERE id = ?";
            }
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdate)) {
                ps.setInt(1, m.getQuantite());
                ps.setInt(2, m.getIdProduit());
                ps.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            System.err.println("MouvementDAO.save : " + e.getMessage());
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    @Override
    public Mouvement findById(int id) {
        String sql = SELECT_BASE + "WHERE m.id = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            System.err.println("MouvementDAO.findById : " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Mouvement> findAll(int page, int pageSize) {
        ObservableList<Mouvement> list = FXCollections.observableArrayList();
        String sql = SELECT_BASE + "ORDER BY m.date_mouvement DESC LIMIT ? OFFSET ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("MouvementDAO.findAll : " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM mouvements";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("MouvementDAO.countAll : " + e.getMessage());
        }
        return 0;
    }

    @Override
    public ObservableList<Mouvement> search(String motCle, String dateDebut, String dateFin, int page, int size) {
        ObservableList<Mouvement> list = FXCollections.observableArrayList();
        StringBuilder sql = new StringBuilder(SELECT_BASE + "WHERE 1=1 ");
        if (motCle != null && !motCle.isEmpty()) sql.append("AND p.designation LIKE ? ");
        if (dateDebut != null && !dateDebut.isEmpty()) sql.append("AND DATE(m.date_mouvement) >= ? ");
        if (dateFin != null && !dateFin.isEmpty()) sql.append("AND DATE(m.date_mouvement) <= ? ");
        sql.append("ORDER BY m.date_mouvement DESC LIMIT ? OFFSET ?");

        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int idx = 1;
            if (motCle != null && !motCle.isEmpty()) ps.setString(idx++, "%" + motCle + "%");
            if (dateDebut != null && !dateDebut.isEmpty()) ps.setString(idx++, dateDebut);
            if (dateFin != null && !dateFin.isEmpty()) ps.setString(idx++, dateFin);
            ps.setInt(idx++, size);
            ps.setInt(idx, (page - 1) * size);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("MouvementDAO.search : " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countSearch(String motCle, String dateDebut, String dateFin) {
        StringBuilder sql = new StringBuilder(
                "SELECT COUNT(*) FROM mouvements m LEFT JOIN produits p ON m.id_produit = p.id WHERE 1=1 ");
        if (motCle != null && !motCle.isEmpty()) sql.append("AND p.designation LIKE ? ");
        if (dateDebut != null && !dateDebut.isEmpty()) sql.append("AND DATE(m.date_mouvement) >= ? ");
        if (dateFin != null && !dateFin.isEmpty()) sql.append("AND DATE(m.date_mouvement) <= ? ");

        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int idx = 1;
            if (motCle != null && !motCle.isEmpty()) ps.setString(idx++, "%" + motCle + "%");
            if (dateDebut != null && !dateDebut.isEmpty()) ps.setString(idx++, dateDebut);
            if (dateFin != null && !dateFin.isEmpty()) ps.setString(idx, dateFin);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("MouvementDAO.countSearch : " + e.getMessage());
        }
        return 0;
    }

    @Override
    public int countMouvementsDuJour() {
        String sql = "SELECT COUNT(*) FROM mouvements WHERE DATE(date_mouvement) = CURDATE()";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("MouvementDAO.countMouvementsDuJour : " + e.getMessage());
        }
        return 0;
    }

    private Mouvement map(ResultSet rs) throws SQLException {
        Mouvement m = new Mouvement(
                rs.getInt("id"),
                rs.getInt("id_produit"),
                rs.getString("type_mouvement"),
                rs.getInt("quantite"),
                rs.getString("motif"),
                rs.getInt("id_utilisateur"),
                null
        );
        Timestamp ts = rs.getTimestamp("date_mouvement");
        if (ts != null) m.setDateMouvement(ts.toLocalDateTime());
        m.setNomProduit(rs.getString("nom_produit"));
        m.setNomUtilisateur(rs.getString("nom_utilisateur"));
        return m;
    }
}

package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.MouvementDAO;
import com.inphb.icgl.stocks.dao.ProduitDAO;
import com.inphb.icgl.stocks.model.Produit;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Contrôleur du tableau de bord.
 * Auteur : LENAUD SOKONI NADIA
 */
public class DashboardController {

    @FXML private Label lblTotalProduits;
    @FXML private Label lblProduitsEnAlerte;
    @FXML private Label lblMouvementsDuJour;
    @FXML private Label lblValeurStock;
    @FXML private Label lblBienvenue;
    @FXML private TableView<Produit> tableAlertes;
    @FXML private TableColumn<Produit, String> colRefAlerte;
    @FXML private TableColumn<Produit, String> colDesAlerte;
    @FXML private TableColumn<Produit, Integer> colQteAlerte;
    @FXML private TableColumn<Produit, Integer> colMinAlerte;
    @FXML private TableColumn<Produit, String> colUniteAlerte;

    private final ProduitDAO produitDAO = new ProduitDAO();
    private final MouvementDAO mouvementDAO = new MouvementDAO();

    @FXML
    public void initialize() {
        configurerTableAlertes();
        rafraichir();

        if (lblBienvenue != null) {
            lblBienvenue.setText("Bonjour, " + SessionManager.getNomComplet() + " 👋");
        }
    }

    private void configurerTableAlertes() {
        colRefAlerte.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colDesAlerte.setCellValueFactory(new PropertyValueFactory<>("designation"));
        colQteAlerte.setCellValueFactory(new PropertyValueFactory<>("quantiteStock"));
        colMinAlerte.setCellValueFactory(new PropertyValueFactory<>("stockMinimum"));
        colUniteAlerte.setCellValueFactory(new PropertyValueFactory<>("unite"));

        // Colorer toutes les lignes en rouge (toutes en alerte)
        tableAlertes.setRowFactory(tv -> new TableRow<Produit>() {
            @Override
            protected void updateItem(Produit p, boolean empty) {
                super.updateItem(p, empty);
                setStyle(p != null && !empty ? "-fx-background-color: #FFEBEE;" : "");
            }
        });
    }

    @FXML
    public void rafraichir() {
        int totalProduits = produitDAO.countAll();
        int enAlerte = produitDAO.countEnAlerte();
        int mouvJour = mouvementDAO.countMouvementsDuJour();
        double valeurStock = produitDAO.getValeurTotaleStock();

        lblTotalProduits.setText(String.valueOf(totalProduits));
        lblProduitsEnAlerte.setText(String.valueOf(enAlerte));
        lblMouvementsDuJour.setText(String.valueOf(mouvJour));

        NumberFormat nf = NumberFormat.getInstance(Locale.FRANCE);
        lblValeurStock.setText(nf.format((long) valeurStock) + " FCFA");

        // Les 5 produits les plus critiques
        ObservableList<Produit> produitsAlerte = produitDAO.findEnAlerte();
        ObservableList<Produit> top5 = javafx.collections.FXCollections.observableArrayList(
                produitsAlerte.size() > 5 ? produitsAlerte.subList(0, 5) : produitsAlerte
        );
        tableAlertes.setItems(top5);
    }
}

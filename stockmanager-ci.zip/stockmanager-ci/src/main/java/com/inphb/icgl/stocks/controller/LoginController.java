package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.UtilisateurDAO;
import com.inphb.icgl.stocks.model.Utilisateur;
import com.inphb.icgl.stocks.utils.AlertUtil;
import com.inphb.icgl.stocks.utils.PasswordUtil;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * Controleur de la fenetre de connexion.
 * Auteur : LENAUD SOKONI NADIA
 */
public class LoginController {

    @FXML private TextField txtLogin;
    @FXML private PasswordField txtPassword;
    @FXML private Button btnConnexion;
    @FXML private Button btnQuitter;
    @FXML private Label lblErreur;
    @FXML private Label lblTentatives;
    @FXML private ProgressIndicator progressIndicator;

    private final UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
    private int tentatives = 0;
    private static final int MAX_TENTATIVES = 3;
    private static final int BLOCAGE_SECONDES = 30;
    private boolean bloque = false;

    @FXML
    public void initialize() {
        lblErreur.setVisible(false);
        lblTentatives.setVisible(false);
        if (progressIndicator != null) {
            progressIndicator.setVisible(false);
        }

        txtPassword.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                handleConnexion();
            }
        });
        txtLogin.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                txtPassword.requestFocus();
            }
        });
    }

    @FXML
    private void handleConnexion() {
        if (bloque) {
            return;
        }

        String login = txtLogin.getText().trim();
        String mdp = txtPassword.getText();

        if (login.isEmpty() || mdp.isEmpty()) {
            afficherErreur("Veuillez remplir tous les champs.");
            return;
        }

        String hash = PasswordUtil.hash(mdp);
        Utilisateur user = utilisateurDAO.authenticate(login, hash);

        if (user != null) {
            SessionManager.setUtilisateur(user);
            ouvrirFenetrePrincipale();
        } else {
            tentatives++;
            int restantes = MAX_TENTATIVES - tentatives;
            if (tentatives >= MAX_TENTATIVES) {
                bloquerConnexion();
            } else {
                afficherErreur("Identifiants incorrects. " + restantes + " tentative(s) restante(s).");
                txtPassword.clear();
                txtPassword.requestFocus();
            }
        }
    }

    private void bloquerConnexion() {
        bloque = true;
        btnConnexion.setDisable(true);
        txtLogin.setDisable(true);
        txtPassword.setDisable(true);
        lblTentatives.setVisible(true);

        final int[] secondesRestantes = {BLOCAGE_SECONDES};
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            secondesRestantes[0]--;
            lblTentatives.setText("Compte bloque. Reessayez dans " + secondesRestantes[0] + "s");
            if (secondesRestantes[0] <= 0) {
                debloquerConnexion();
            }
        }));
        timeline.setCycleCount(BLOCAGE_SECONDES);
        timeline.play();

        afficherErreur("3 tentatives echouees. Connexion bloquee 30 secondes.");
    }

    private void debloquerConnexion() {
        bloque = false;
        tentatives = 0;
        btnConnexion.setDisable(false);
        txtLogin.setDisable(false);
        txtPassword.setDisable(false);
        lblTentatives.setVisible(false);
        lblErreur.setVisible(false);
        txtPassword.clear();
        txtLogin.requestFocus();
    }

    private void afficherErreur(String msg) {
        lblErreur.setText(msg);
        lblErreur.setVisible(true);
    }

    private void ouvrirFenetrePrincipale() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/MainLayout.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("LAD Stock - " + SessionManager.getNomComplet() +
                           " [" + SessionManager.getRole() + "]");
            stage.setScene(new Scene(root, 1280, 780));
            stage.setMinWidth(1024);
            stage.setMinHeight(680);
            stage.getIcons().add(new Image(getClass().getResourceAsStream("/images/logo.png")));
            stage.show();

            Stage loginStage = (Stage) btnConnexion.getScene().getWindow();
            loginStage.close();
        } catch (Exception e) {
            AlertUtil.showError("Erreur", "Impossible d'ouvrir l'application : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleQuitter() {
        System.exit(0);
    }
}

package com.inphb.icgl.stocks.utils;

import com.inphb.icgl.stocks.model.Produit;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Utilitaire d'export des données en XLSX (Apache POI) et PDF (iTextPDF).
 * Auteur : LENAUD SOKONI NADIA
 */
public class ExportUtil {

    private ExportUtil() {}

    // ══════════════════════════════════════════════════════════════
    // EXPORT XLSX
    // ══════════════════════════════════════════════════════════════

    public static void exporterXLSX(List<Produit> produits, File fichier) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Produits - LAD Stock");

            // ── Style : en-tête (vert foncé + texte blanc) ──────────
            XSSFCellStyle styleEntete = workbook.createCellStyle();
            styleEntete.setFillForegroundColor(new XSSFColor(new byte[]{(byte) 27, (byte) 94, (byte) 32}, null));
            styleEntete.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            styleEntete.setAlignment(HorizontalAlignment.CENTER);
            styleEntete.setBorderBottom(BorderStyle.THIN);
            styleEntete.setBorderTop(BorderStyle.THIN);
            styleEntete.setBorderLeft(BorderStyle.THIN);
            styleEntete.setBorderRight(BorderStyle.THIN);
            XSSFFont fontEntete = workbook.createFont();
            fontEntete.setColor(IndexedColors.WHITE.getIndex());
            fontEntete.setBold(true);
            fontEntete.setFontHeightInPoints((short) 11);
            styleEntete.setFont(fontEntete);

            // ── Style : cellule alerte rouge clair ──────────────────
            XSSFCellStyle styleAlerte = workbook.createCellStyle();
            styleAlerte.setFillForegroundColor(new XSSFColor(new byte[]{(byte) 255, (byte) 204, (byte) 204}, null));
            styleAlerte.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            styleAlerte.setBorderBottom(BorderStyle.THIN);
            styleAlerte.setBorderTop(BorderStyle.THIN);
            styleAlerte.setBorderLeft(BorderStyle.THIN);
            styleAlerte.setBorderRight(BorderStyle.THIN);

            // ── Style : cellule normale ──────────────────────────────
            XSSFCellStyle styleNormal = workbook.createCellStyle();
            styleNormal.setBorderBottom(BorderStyle.THIN);
            styleNormal.setBorderTop(BorderStyle.THIN);
            styleNormal.setBorderLeft(BorderStyle.THIN);
            styleNormal.setBorderRight(BorderStyle.THIN);

            // ── Ligne titre ──────────────────────────────────────────
            Row ligneTitre = sheet.createRow(0);
            Cell cellTitre = ligneTitre.createCell(0);
            cellTitre.setCellValue("STOCKMANAGER CI — Liste des produits — " +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
            XSSFCellStyle styleTitre = workbook.createCellStyle();
            styleTitre.setFillForegroundColor(new XSSFColor(new byte[]{(byte) 15, (byte) 60, (byte) 20}, null));
            styleTitre.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            XSSFFont fontTitre = workbook.createFont();
            fontTitre.setColor(IndexedColors.WHITE.getIndex());
            fontTitre.setBold(true);
            fontTitre.setFontHeightInPoints((short) 13);
            styleTitre.setFont(fontTitre);
            cellTitre.setCellStyle(styleTitre);
            sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, 0, 8));
            ligneTitre.setHeightInPoints(25);

            // ── Ligne d'en-tête ──────────────────────────────────────
            String[] entetes = {"Référence", "Désignation", "Catégorie", "Fournisseur",
                    "Prix (FCFA)", "Quantité", "Stock Min", "Unité", "⚠ Alerte"};
            int[] largeurs = {4500, 7000, 5000, 5500, 4000, 3500, 3500, 3000, 3500};
            Row ligneEntete = sheet.createRow(1);
            ligneEntete.setHeightInPoints(20);
            for (int i = 0; i < entetes.length; i++) {
                Cell cell = ligneEntete.createCell(i);
                cell.setCellValue(entetes[i]);
                cell.setCellStyle(styleEntete);
                sheet.setColumnWidth(i, largeurs[i]);
            }

            // ── Lignes de données ────────────────────────────────────
            int numLigne = 2;
            for (Produit p : produits) {
                Row row = sheet.createRow(numLigne++);
                row.setHeightInPoints(18);
                boolean enAlerte = p.getQuantiteStock() <= p.getStockMinimum();
                XSSFCellStyle styleLigne = enAlerte ? styleAlerte : styleNormal;

                String[] valeurs = {
                        p.getReference(),
                        p.getDesignation(),
                        p.getNomCategorie() != null ? p.getNomCategorie() : "—",
                        p.getNomFournisseur() != null ? p.getNomFournisseur() : "—",
                        String.format("%.0f", p.getPrixUnitaire()),
                        String.valueOf(p.getQuantiteStock()),
                        String.valueOf(p.getStockMinimum()),
                        p.getUnite(),
                        enAlerte ? "⚠ OUI" : "NON"
                };

                for (int i = 0; i < valeurs.length; i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(valeurs[i]);
                    cell.setCellStyle(styleLigne);
                }
            }

            // ── Sauvegarder ──────────────────────────────────────────
            try (FileOutputStream fos = new FileOutputStream(fichier)) {
                workbook.write(fos);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // EXPORT PDF (BONUS)
    // ══════════════════════════════════════════════════════════════

    public static void exporterPDF(List<Produit> produits, File fichier) throws Exception {
        Document document = new Document(PageSize.A4.rotate(), 20, 20, 30, 30);
        PdfWriter.getInstance(document, new FileOutputStream(fichier));
        document.open();

        // Titre
        Font fontTitre = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.WHITE);
        PdfPTable tabletitre = new PdfPTable(1);
        tabletitre.setWidthPercentage(100);
        PdfPCell cellTitre = new PdfPCell(new Phrase("STOCKMANAGER CI — Liste des produits", fontTitre));
        cellTitre.setBackgroundColor(new BaseColor(27, 94, 32));
        cellTitre.setHorizontalAlignment(Element.ALIGN_CENTER);
        cellTitre.setPadding(10);
        tabletitre.addCell(cellTitre);
        document.add(tabletitre);

        // Date
        Font fontDate = new Font(Font.FontFamily.HELVETICA, 9, Font.ITALIC, BaseColor.GRAY);
        Paragraph dateP = new Paragraph("Exporté le : " +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy à HH:mm")), fontDate);
        dateP.setAlignment(Element.ALIGN_RIGHT);
        dateP.setSpacingBefore(5);
        dateP.setSpacingAfter(10);
        document.add(dateP);

        // Tableau
        PdfPTable table = new PdfPTable(9);
        table.setWidthPercentage(100);
        float[] widths = {3f, 5f, 3.5f, 4f, 3f, 2.5f, 2.5f, 2.5f, 2.5f};
        table.setWidths(widths);

        // En-têtes
        String[] entetes = {"Référence", "Désignation", "Catégorie", "Fournisseur",
                "Prix FCFA", "Quantité", "Stock Min", "Unité", "Alerte"};
        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 9, Font.BOLD, BaseColor.WHITE);
        BaseColor couleurHeader = new BaseColor(27, 94, 32);
        for (String entete : entetes) {
            PdfPCell cell = new PdfPCell(new Phrase(entete, fontHeader));
            cell.setBackgroundColor(couleurHeader);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(6);
            table.addCell(cell);
        }

        // Données
        Font fontData = new Font(Font.FontFamily.HELVETICA, 8);
        Font fontAlerte = new Font(Font.FontFamily.HELVETICA, 8, Font.BOLD, BaseColor.RED);
        BaseColor couleurAlerte = new BaseColor(255, 220, 220);

        for (Produit p : produits) {
            boolean enAlerte = p.getQuantiteStock() <= p.getStockMinimum();
            BaseColor bgColor = enAlerte ? couleurAlerte : BaseColor.WHITE;
            Font fontRow = enAlerte ? fontAlerte : fontData;

            String[] valeurs = {
                    p.getReference(),
                    p.getDesignation(),
                    p.getNomCategorie() != null ? p.getNomCategorie() : "—",
                    p.getNomFournisseur() != null ? p.getNomFournisseur() : "—",
                    String.format("%.0f", p.getPrixUnitaire()),
                    String.valueOf(p.getQuantiteStock()),
                    String.valueOf(p.getStockMinimum()),
                    p.getUnite(),
                    enAlerte ? "⚠ OUI" : "NON"
            };

            for (String valeur : valeurs) {
                PdfPCell cell = new PdfPCell(new Phrase(valeur, fontRow));
                cell.setBackgroundColor(bgColor);
                cell.setPadding(4);
                table.addCell(cell);
            }
        }

        document.add(table);

        // Pied de page
        Paragraph footer = new Paragraph(
                "LAD Stock — INP-HB IC-GL 2025-2026 | " + produits.size() + " produits exportés",
                new Font(Font.FontFamily.HELVETICA, 8, Font.ITALIC, BaseColor.GRAY));
        footer.setAlignment(Element.ALIGN_CENTER);
        footer.setSpacingBefore(15);
        document.add(footer);

        document.close();
    }
}

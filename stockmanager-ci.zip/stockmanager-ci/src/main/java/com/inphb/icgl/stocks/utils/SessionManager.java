package com.inphb.icgl.stocks.utils;

import com.inphb.icgl.stocks.model.Utilisateur;

/**
 * Gestionnaire de session utilisateur (Singleton statique).
 * Accessible depuis tous les contrôleurs sans paramètre.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class SessionManager {

    private static Utilisateur utilisateurConnecte = null;

    private SessionManager() {}

    public static void setUtilisateur(Utilisateur u) {
        utilisateurConnecte = u;
    }

    public static Utilisateur getUtilisateur() {
        return utilisateurConnecte;
    }

    public static boolean isAdmin() {
        return utilisateurConnecte != null &&
               "ADMIN".equals(utilisateurConnecte.getRole());
    }

    public static boolean isConnected() {
        return utilisateurConnecte != null;
    }

    public static String getNomComplet() {
        return utilisateurConnecte != null ? utilisateurConnecte.getNomComplet() : "";
    }

    public static String getRole() {
        return utilisateurConnecte != null ? utilisateurConnecte.getRole() : "";
    }

    public static int getUserId() {
        return utilisateurConnecte != null ? utilisateurConnecte.getId() : -1;
    }

    public static void logout() {
        utilisateurConnecte = null;
    }
}

package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Categorie;
import javafx.collections.ObservableList;

/**
 * Interface Repository pour les catégories.
 * Auteur : LENAUD SOKONI NADIA
 */
public interface ICategorieRepository {
    boolean save(Categorie c);
    boolean update(Categorie c);
    boolean delete(int id);
    Categorie findById(int id);
    ObservableList<Categorie> findAll(int page, int pageSize);
    ObservableList<Categorie> findAllNoPagination();
    int countAll();
    ObservableList<Categorie> search(String motCle, int page, int size);
    int countSearch(String motCle);
    boolean hasProducts(int id);
}

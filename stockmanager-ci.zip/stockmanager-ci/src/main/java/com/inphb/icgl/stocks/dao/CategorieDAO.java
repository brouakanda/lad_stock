package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Categorie;
import com.inphb.icgl.stocks.repository.ICategorieRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

/**
 * DAO pour les catégories — implémentation SQL avec PreparedStatement.
 * Auteur : DOUMBIA KARIDJATOU
 */
public class CategorieDAO implements ICategorieRepository {

    @Override
    public boolean save(Categorie c) {
        String sql = "INSERT INTO categories (libelle, description) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getLibelle());
            ps.setString(2, c.getDescription());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("CategorieDAO.save : " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Categorie c) {
        String sql = "UPDATE categories SET libelle = ?, description = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getLibelle());
            ps.setString(2, c.getDescription());
            ps.setInt(3, c.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("CategorieDAO.update : " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM categories WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("CategorieDAO.delete : " + e.getMessage());
            return false;
        }
    }

    @Override
    public Categorie findById(int id) {
        String sql = "SELECT * FROM categories WHERE id = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            System.err.println("CategorieDAO.findById : " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Categorie> findAll(int page, int pageSize) {
        ObservableList<Categorie> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM categories ORDER BY libelle LIMIT ? OFFSET ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("CategorieDAO.findAll : " + e.getMessage());
        }
        return list;
    }

    @Override
    public ObservableList<Categorie> findAllNoPagination() {
        ObservableList<Categorie> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM categories ORDER BY libelle";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("CategorieDAO.findAllNoPagination : " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM categories";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("CategorieDAO.countAll : " + e.getMessage());
        }
        return 0;
    }

    @Override
    public ObservableList<Categorie> search(String motCle, int page, int size) {
        ObservableList<Categorie> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM categories WHERE libelle LIKE ? ORDER BY libelle LIMIT ? OFFSET ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + motCle + "%");
            ps.setInt(2, size);
            ps.setInt(3, (page - 1) * size);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (SQLException e) {
            System.err.println("CategorieDAO.search : " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countSearch(String motCle) {
        String sql = "SELECT COUNT(*) FROM categories WHERE libelle LIKE ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + motCle + "%");
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("CategorieDAO.countSearch : " + e.getMessage());
        }
        return 0;
    }

    @Override
    public boolean hasProducts(int id) {
        String sql = "SELECT COUNT(*) FROM produits WHERE id_categorie = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("CategorieDAO.hasProducts : " + e.getMessage());
        }
        return false;
    }

    private Categorie map(ResultSet rs) throws SQLException {
        return new Categorie(
                rs.getInt("id"),
                rs.getString("libelle"),
                rs.getString("description")
        );
    }
}

package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.MouvementDAO;
import com.inphb.icgl.stocks.dao.ProduitDAO;
import com.inphb.icgl.stocks.model.Mouvement;
import com.inphb.icgl.stocks.model.Produit;
import com.inphb.icgl.stocks.utils.AlertUtil;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Contrôleur du module Mouvements de stock.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class MouvementController {

    @FXML private TableView<Mouvement> tableMouvements;
    @FXML private TableColumn<Mouvement, Integer> colId;
    @FXML private TableColumn<Mouvement, String> colProduit;
    @FXML private TableColumn<Mouvement, String> colType;
    @FXML private TableColumn<Mouvement, Integer> colQuantite;
    @FXML private TableColumn<Mouvement, String> colMotif;
    @FXML private TableColumn<Mouvement, String> colDate;
    @FXML private TableColumn<Mouvement, String> colUtilisateur;

    @FXML private ComboBox<Produit> cbProduit;
    @FXML private ComboBox<String> cbTypeMouvement;
    @FXML private TextField txtQuantite;
    @FXML private TextField txtMotif;
    @FXML private Label lblStockActuel;
    @FXML private TextField txtRecherche;
    @FXML private DatePicker dpDebut;
    @FXML private DatePicker dpFin;

    @FXML private Button btnEnregistrer;
    @FXML private Label lblStatut;
    @FXML private Label lblPage;
    @FXML private Button btnPrecedent;
    @FXML private Button btnSuivant;

    private final MouvementDAO mouvementDAO = new MouvementDAO();
    private final ProduitDAO produitDAO = new ProduitDAO();
    private int pageCourante = 1;
    private static final int PAGE_SIZE = 15;
    private int totalPages = 1;

    @FXML
    public void initialize() {
        configurerColonnes();
        configurerCombos();
        configurerSelection();
        chargerDonnees();
    }

    private void configurerColonnes() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colProduit.setCellValueFactory(new PropertyValueFactory<>("nomProduit"));
        colType.setCellValueFactory(new PropertyValueFactory<>("typeMouvement"));
        colQuantite.setCellValueFactory(new PropertyValueFactory<>("quantite"));
        colMotif.setCellValueFactory(new PropertyValueFactory<>("motif"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("dateFormatee"));
        colUtilisateur.setCellValueFactory(new PropertyValueFactory<>("nomUtilisateur"));

        // Colorier les entrées en vert, sorties en rouge
        colType.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String type, boolean empty) {
                super.updateItem(type, empty);
                if (empty || type == null) {
                    setText(null);
                    setStyle("");
                } else if ("ENTREE".equals(type)) {
                    setText("⬆ ENTRÉE");
                    setStyle("-fx-text-fill: #1b5e20; -fx-font-weight: bold;");
                } else {
                    setText("⬇ SORTIE");
                    setStyle("-fx-text-fill: #b71c1c; -fx-font-weight: bold;");
                }
            }
        });
    }

    private void configurerCombos() {
        cbProduit.setItems(produitDAO.findAllNoPagination());
        cbTypeMouvement.setItems(FXCollections.observableArrayList("ENTREE", "SORTIE"));
        cbTypeMouvement.setValue("ENTREE");

        cbProduit.valueProperty().addListener((obs, old, selected) -> {
            if (selected != null && lblStockActuel != null) {
                Produit p = produitDAO.findById(selected.getId());
                if (p != null) {
                    lblStockActuel.setText("Stock actuel : " + p.getQuantiteStock() + " " + p.getUnite());
                    lblStockActuel.setStyle(p.isEnAlerte() ?
                            "-fx-text-fill: #c0392b; -fx-font-weight: bold;" :
                            "-fx-text-fill: #27ae60; -fx-font-weight: bold;");
                }
            }
        });
    }

    private void configurerSelection() {
        if (txtRecherche != null) {
            txtRecherche.textProperty().addListener((obs, old, val) -> {
                pageCourante = 1;
                chargerDonnees();
            });
        }
    }

    private void chargerDonnees() {
        String motCle = txtRecherche != null ? txtRecherche.getText().trim() : "";
        String dateDebut = (dpDebut != null && dpDebut.getValue() != null) ? dpDebut.getValue().toString() : null;
        String dateFin = (dpFin != null && dpFin.getValue() != null) ? dpFin.getValue().toString() : null;

        ObservableList<Mouvement> data;
        int total;
        if (motCle.isEmpty() && dateDebut == null && dateFin == null) {
            data = mouvementDAO.findAll(pageCourante, PAGE_SIZE);
            total = mouvementDAO.countAll();
        } else {
            data = mouvementDAO.search(motCle, dateDebut, dateFin, pageCourante, PAGE_SIZE);
            total = mouvementDAO.countSearch(motCle, dateDebut, dateFin);
        }
        tableMouvements.setItems(data);
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        lblPage.setText("Page " + pageCourante + " / " + totalPages + "  —  " + total + " mouvement(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { if (pageCourante > 1) { pageCourante--; chargerDonnees(); } }
    @FXML private void handleSuivant()   { if (pageCourante < totalPages) { pageCourante++; chargerDonnees(); } }
    @FXML private void handleFiltrer()   { pageCourante = 1; chargerDonnees(); }
    @FXML private void handleReset()     {
        if (txtRecherche != null) txtRecherche.clear();
        if (dpDebut != null) dpDebut.setValue(null);
        if (dpFin != null) dpFin.setValue(null);
        pageCourante = 1;
        chargerDonnees();
    }

    @FXML
    private void handleEnregistrer() {
        Produit produitChoisi = cbProduit.getValue();
        String type = cbTypeMouvement.getValue();

        if (produitChoisi == null) {
            AlertUtil.showWarning("Champ requis", "Veuillez sélectionner un produit.");
            return;
        }
        if (type == null || type.isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Veuillez choisir le type de mouvement.");
            return;
        }

        int quantite;
        try {
            quantite = Integer.parseInt(txtQuantite.getText().trim());
            if (quantite <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            AlertUtil.showWarning("Valeur invalide", "La quantité doit être un entier strictement positif.");
            return;
        }

        // Vérifier stock suffisant pour une sortie
        if ("SORTIE".equals(type)) {
            Produit produitActuel = produitDAO.findById(produitChoisi.getId());
            if (produitActuel != null && quantite > produitActuel.getQuantiteStock()) {
                AlertUtil.showWarning("Stock insuffisant",
                        "Stock disponible : " + produitActuel.getQuantiteStock() +
                        " " + produitActuel.getUnite() + "\nVous ne pouvez pas sortir " + quantite + " unités.");
                return;
            }
        }

        Mouvement m = new Mouvement();
        m.setIdProduit(produitChoisi.getId());
        m.setTypeMouvement(type);
        m.setQuantite(quantite);
        m.setMotif(txtMotif.getText().trim());
        m.setIdUtilisateur(SessionManager.getUserId());

        if (mouvementDAO.save(m)) {
            afficherStatut("✔ Mouvement enregistré — Stock mis à jour.");
            viderFormulaire();
            chargerDonnees();
            // Rafraîchir le stock actuel affiché
            Produit maj = produitDAO.findById(produitChoisi.getId());
            if (maj != null && lblStockActuel != null) {
                lblStockActuel.setText("Stock actuel : " + maj.getQuantiteStock() + " " + maj.getUnite());
                lblStockActuel.setStyle(maj.isEnAlerte() ?
                        "-fx-text-fill: #c0392b; -fx-font-weight: bold;" :
                        "-fx-text-fill: #27ae60; -fx-font-weight: bold;");
            }
        } else {
            AlertUtil.showError("Erreur", "Impossible d'enregistrer le mouvement.");
        }
    }

    private void viderFormulaire() {
        cbProduit.setValue(null);
        cbTypeMouvement.setValue("ENTREE");
        txtQuantite.clear();
        txtMotif.clear();
        if (lblStockActuel != null) lblStockActuel.setText("Stock actuel : —");
    }

    private void afficherStatut(String msg) { lblStatut.setText(msg); }
}

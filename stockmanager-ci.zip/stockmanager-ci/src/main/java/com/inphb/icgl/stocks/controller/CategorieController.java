package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.CategorieDAO;
import com.inphb.icgl.stocks.model.Categorie;
import com.inphb.icgl.stocks.utils.AlertUtil;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Contrôleur du module Catégories.
 * Auteur : DOUMBIA KARIDJATOU
 */
public class CategorieController {

    @FXML private TableView<Categorie> tableCategories;
    @FXML private TableColumn<Categorie, Integer> colId;
    @FXML private TableColumn<Categorie, String> colLibelle;
    @FXML private TableColumn<Categorie, String> colDescription;
    @FXML private TextField txtLibelle;
    @FXML private TextField txtDescription;
    @FXML private TextField txtRecherche;
    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;
    @FXML private Label lblStatut;
    @FXML private Label lblPage;
    @FXML private Button btnPrecedent;
    @FXML private Button btnSuivant;

    private final CategorieDAO categorieDAO = new CategorieDAO();
    private Categorie categorieSelectionnee = null;
    private int pageCourante = 1;
    private static final int PAGE_SIZE = 15;
    private int totalPages = 1;
    private String motCleRecherche = "";

    @FXML
    public void initialize() {
        configurerColonnes();
        configurerSelection();
        configurerRecherche();
        chargerDonnees();
        modeAjout();
    }

    private void configurerColonnes() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colLibelle.setCellValueFactory(new PropertyValueFactory<>("libelle"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
    }

    private void configurerSelection() {
        tableCategories.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                categorieSelectionnee = selected;
                txtLibelle.setText(selected.getLibelle());
                txtDescription.setText(selected.getDescription() != null ? selected.getDescription() : "");
                btnModifier.setDisable(false);
                btnSupprimer.setDisable(false);
            }
        });
    }

    private void configurerRecherche() {
        txtRecherche.textProperty().addListener((obs, old, val) -> {
            motCleRecherche = val.trim();
            pageCourante = 1;
            chargerDonnees();
        });
    }

    private void chargerDonnees() {
        ObservableList<Categorie> data;
        int total;
        if (motCleRecherche.isEmpty()) {
            data = categorieDAO.findAll(pageCourante, PAGE_SIZE);
            total = categorieDAO.countAll();
        } else {
            data = categorieDAO.search(motCleRecherche, pageCourante, PAGE_SIZE);
            total = categorieDAO.countSearch(motCleRecherche);
        }
        tableCategories.setItems(data);
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        lblPage.setText("Page " + pageCourante + " / " + totalPages + "  —  " + total + " catégorie(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { if (pageCourante > 1) { pageCourante--; chargerDonnees(); } }
    @FXML private void handleSuivant()   { if (pageCourante < totalPages) { pageCourante++; chargerDonnees(); } }

    @FXML
    private void handleAjouter() {
        String libelle = txtLibelle.getText().trim();
        if (libelle.isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le libellé de la catégorie est obligatoire.");
            return;
        }
        Categorie c = new Categorie(0, libelle, txtDescription.getText().trim());
        if (categorieDAO.save(c)) {
            afficherStatut("✔ Catégorie ajoutée avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible d'ajouter la catégorie (libellé déjà existant ?)");
        }
    }

    @FXML
    private void handleModifier() {
        if (categorieSelectionnee == null) return;
        String libelle = txtLibelle.getText().trim();
        if (libelle.isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le libellé est obligatoire.");
            return;
        }
        categorieSelectionnee.setLibelle(libelle);
        categorieSelectionnee.setDescription(txtDescription.getText().trim());
        if (categorieDAO.update(categorieSelectionnee)) {
            afficherStatut("✔ Catégorie modifiée avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible de modifier la catégorie.");
        }
    }

    @FXML
    private void handleSupprimer() {
        if (categorieSelectionnee == null) return;
        if (categorieDAO.hasProducts(categorieSelectionnee.getId())) {
            AlertUtil.showWarning("Suppression impossible",
                    "Cette catégorie contient des produits.\nSupprimez ou réaffectez les produits avant.");
            return;
        }
        boolean confirm = AlertUtil.showConfirmation("Confirmer la suppression",
                "Supprimer la catégorie « " + categorieSelectionnee.getLibelle() + " » ?");
        if (confirm) {
            if (categorieDAO.delete(categorieSelectionnee.getId())) {
                afficherStatut("✔ Catégorie supprimée.");
                modeAjout();
                chargerDonnees();
            } else {
                AlertUtil.showError("Erreur", "Impossible de supprimer la catégorie.");
            }
        }
    }

    @FXML
    private void handleNouveau() { modeAjout(); }

    private void modeAjout() {
        categorieSelectionnee = null;
        txtLibelle.clear();
        txtDescription.clear();
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
        tableCategories.getSelectionModel().clearSelection();
        lblStatut.setText("");
    }

    private void afficherStatut(String msg) {
        lblStatut.setText(msg);
    }
}

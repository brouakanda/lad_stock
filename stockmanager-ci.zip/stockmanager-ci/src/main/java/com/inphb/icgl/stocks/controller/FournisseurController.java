package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.FournisseurDAO;
import com.inphb.icgl.stocks.model.Fournisseur;
import com.inphb.icgl.stocks.utils.AlertUtil;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Contrôleur du module Fournisseurs.
 * Auteur : DOUMBIA KARIDJATOU
 */
public class FournisseurController {

    @FXML private TableView<Fournisseur> tableFournisseurs;
    @FXML private TableColumn<Fournisseur, Integer> colId;
    @FXML private TableColumn<Fournisseur, String> colNom;
    @FXML private TableColumn<Fournisseur, String> colTelephone;
    @FXML private TableColumn<Fournisseur, String> colEmail;
    @FXML private TableColumn<Fournisseur, String> colAdresse;
    @FXML private TableColumn<Fournisseur, String> colVille;
    @FXML private TextField txtNom;
    @FXML private TextField txtTelephone;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAdresse;
    @FXML private TextField txtVille;
    @FXML private TextField txtRecherche;
    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;
    @FXML private Label lblStatut;
    @FXML private Label lblPage;
    @FXML private Button btnPrecedent;
    @FXML private Button btnSuivant;

    private final FournisseurDAO fournisseurDAO = new FournisseurDAO();
    private Fournisseur fournisseurSelectionne = null;
    private int pageCourante = 1;
    private static final int PAGE_SIZE = 15;
    private int totalPages = 1;
    private String motCleRecherche = "";

    @FXML
    public void initialize() {
        configurerColonnes();
        configurerSelection();
        configurerRecherche();
        chargerDonnees();
        modeAjout();
    }

    private void configurerColonnes() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colAdresse.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        colVille.setCellValueFactory(new PropertyValueFactory<>("ville"));
    }

    private void configurerSelection() {
        tableFournisseurs.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                fournisseurSelectionne = selected;
                txtNom.setText(selected.getNom());
                txtTelephone.setText(selected.getTelephone() != null ? selected.getTelephone() : "");
                txtEmail.setText(selected.getEmail() != null ? selected.getEmail() : "");
                txtAdresse.setText(selected.getAdresse() != null ? selected.getAdresse() : "");
                txtVille.setText(selected.getVille() != null ? selected.getVille() : "");
                btnModifier.setDisable(false);
                btnSupprimer.setDisable(false);
            }
        });
    }

    private void configurerRecherche() {
        txtRecherche.textProperty().addListener((obs, old, val) -> {
            motCleRecherche = val.trim();
            pageCourante = 1;
            chargerDonnees();
        });
    }

    private void chargerDonnees() {
        ObservableList<Fournisseur> data;
        int total;
        if (motCleRecherche.isEmpty()) {
            data = fournisseurDAO.findAll(pageCourante, PAGE_SIZE);
            total = fournisseurDAO.countAll();
        } else {
            data = fournisseurDAO.search(motCleRecherche, pageCourante, PAGE_SIZE);
            total = fournisseurDAO.countSearch(motCleRecherche);
        }
        tableFournisseurs.setItems(data);
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        lblPage.setText("Page " + pageCourante + " / " + totalPages + "  —  " + total + " fournisseur(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { if (pageCourante > 1) { pageCourante--; chargerDonnees(); } }
    @FXML private void handleSuivant()   { if (pageCourante < totalPages) { pageCourante++; chargerDonnees(); } }

    @FXML
    private void handleAjouter() {
        String nom = txtNom.getText().trim();
        if (nom.isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le nom du fournisseur est obligatoire.");
            return;
        }
        Fournisseur f = new Fournisseur(0, nom,
                txtTelephone.getText().trim(), txtEmail.getText().trim(),
                txtAdresse.getText().trim(), txtVille.getText().trim());
        if (fournisseurDAO.save(f)) {
            afficherStatut("✔ Fournisseur ajouté avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible d'ajouter le fournisseur.");
        }
    }

    @FXML
    private void handleModifier() {
        if (fournisseurSelectionne == null) return;
        String nom = txtNom.getText().trim();
        if (nom.isEmpty()) {
            AlertUtil.showWarning("Champ requis", "Le nom est obligatoire.");
            return;
        }
        fournisseurSelectionne.setNom(nom);
        fournisseurSelectionne.setTelephone(txtTelephone.getText().trim());
        fournisseurSelectionne.setEmail(txtEmail.getText().trim());
        fournisseurSelectionne.setAdresse(txtAdresse.getText().trim());
        fournisseurSelectionne.setVille(txtVille.getText().trim());
        if (fournisseurDAO.update(fournisseurSelectionne)) {
            afficherStatut("✔ Fournisseur modifié avec succès.");
            modeAjout();
            chargerDonnees();
        } else {
            AlertUtil.showError("Erreur", "Impossible de modifier le fournisseur.");
        }
    }

    @FXML
    private void handleSupprimer() {
        if (fournisseurSelectionne == null) return;
        if (fournisseurDAO.hasProducts(fournisseurSelectionne.getId())) {
            AlertUtil.showWarning("Suppression impossible",
                    "Ce fournisseur a des produits associés.\nRéaffectez les produits avant la suppression.");
            return;
        }
        boolean confirm = AlertUtil.showConfirmation("Confirmer",
                "Supprimer le fournisseur « " + fournisseurSelectionne.getNom() + " » ?");
        if (confirm) {
            if (fournisseurDAO.delete(fournisseurSelectionne.getId())) {
                afficherStatut("✔ Fournisseur supprimé.");
                modeAjout();
                chargerDonnees();
            } else {
                AlertUtil.showError("Erreur", "Impossible de supprimer le fournisseur.");
            }
        }
    }

    @FXML private void handleNouveau() { modeAjout(); }

    private void modeAjout() {
        fournisseurSelectionne = null;
        txtNom.clear(); txtTelephone.clear(); txtEmail.clear();
        txtAdresse.clear(); txtVille.clear();
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
        tableFournisseurs.getSelectionModel().clearSelection();
        lblStatut.setText("");
    }

    private void afficherStatut(String msg) { lblStatut.setText(msg); }
}

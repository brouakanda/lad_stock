package com.inphb.icgl.stocks;

/**
 * Point d'entrée pour lancer l'application depuis un IDE.
 * Cette classe évite l'erreur "JavaFX runtime components are missing"
 * causée par Java 11+ qui vérifie le module JavaFX sur la classe Application.
 * En passant par un Launcher ordinaire, la vérification est contournée.
 */
public class Launcher {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}

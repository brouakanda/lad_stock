package com.inphb.icgl.stocks.model;

import javafx.beans.property.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Modèle Mouvement de stock avec Properties JavaFX.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class Mouvement {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final IntegerProperty id = new SimpleIntegerProperty();
    private final IntegerProperty idProduit = new SimpleIntegerProperty();
    private final StringProperty typeMouvement = new SimpleStringProperty();
    private final IntegerProperty quantite = new SimpleIntegerProperty();
    private final StringProperty motif = new SimpleStringProperty();
    private final IntegerProperty idUtilisateur = new SimpleIntegerProperty();
    private LocalDateTime dateMouvement;

    // Champs de jointure
    private final StringProperty nomProduit = new SimpleStringProperty();
    private final StringProperty nomUtilisateur = new SimpleStringProperty();
    private final StringProperty dateFormatee = new SimpleStringProperty();

    public Mouvement() {}

    public Mouvement(int id, int idProduit, String typeMouvement, int quantite,
                     String motif, int idUtilisateur, LocalDateTime dateMouvement) {
        setId(id);
        setIdProduit(idProduit);
        setTypeMouvement(typeMouvement);
        setQuantite(quantite);
        setMotif(motif);
        setIdUtilisateur(idUtilisateur);
        setDateMouvement(dateMouvement);
    }

    // ── Getters / Setters ──────────────────────────────────────────
    public int getId() { return id.get(); }
    public void setId(int v) { id.set(v); }
    public IntegerProperty idProperty() { return id; }

    public int getIdProduit() { return idProduit.get(); }
    public void setIdProduit(int v) { idProduit.set(v); }
    public IntegerProperty idProduitProperty() { return idProduit; }

    public String getTypeMouvement() { return typeMouvement.get(); }
    public void setTypeMouvement(String v) { typeMouvement.set(v); }
    public StringProperty typeMouvementProperty() { return typeMouvement; }

    public int getQuantite() { return quantite.get(); }
    public void setQuantite(int v) { quantite.set(v); }
    public IntegerProperty quantiteProperty() { return quantite; }

    public String getMotif() { return motif.get(); }
    public void setMotif(String v) { motif.set(v); }
    public StringProperty motifProperty() { return motif; }

    public int getIdUtilisateur() { return idUtilisateur.get(); }
    public void setIdUtilisateur(int v) { idUtilisateur.set(v); }
    public IntegerProperty idUtilisateurProperty() { return idUtilisateur; }

    public LocalDateTime getDateMouvement() { return dateMouvement; }
    public void setDateMouvement(LocalDateTime v) {
        this.dateMouvement = v;
        if (v != null) setDateFormatee(v.format(FORMATTER));
    }

    public String getNomProduit() { return nomProduit.get(); }
    public void setNomProduit(String v) { nomProduit.set(v); }
    public StringProperty nomProduitProperty() { return nomProduit; }

    public String getNomUtilisateur() { return nomUtilisateur.get(); }
    public void setNomUtilisateur(String v) { nomUtilisateur.set(v); }
    public StringProperty nomUtilisateurProperty() { return nomUtilisateur; }

    public String getDateFormatee() { return dateFormatee.get(); }
    public void setDateFormatee(String v) { dateFormatee.set(v); }
    public StringProperty dateFormateeProperty() { return dateFormatee; }
}

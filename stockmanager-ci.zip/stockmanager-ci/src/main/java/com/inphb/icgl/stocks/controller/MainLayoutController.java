package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.utils.AlertUtil;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Contrôleur du layout principal (menu + navigation dynamique).
 * Auteur : LENAUD SOKONI NADIA
 */
public class MainLayoutController {

    @FXML private BorderPane mainPane;
    @FXML private MenuItem menuUtilisateurs;
    @FXML private Label lblUserInfo;
    @FXML private Label lblRole;

    @FXML
    public void initialize() {
        // Restreindre le menu Utilisateurs aux ADMIN uniquement
        if (menuUtilisateurs != null) {
            menuUtilisateurs.setVisible(SessionManager.isAdmin());
        }

        // Afficher les infos de l'utilisateur connecté
        if (lblUserInfo != null) {
            lblUserInfo.setText(SessionManager.getNomComplet());
        }
        if (lblRole != null) {
            lblRole.setText(SessionManager.getRole());
            if (SessionManager.isAdmin()) {
                lblRole.setStyle("-fx-text-fill: #f39c12; -fx-font-weight: bold;");
            } else {
                lblRole.setStyle("-fx-text-fill: #2ecc71; -fx-font-weight: bold;");
            }
        }

        // Charger le Dashboard au démarrage
        chargerVue("Dashboard");
    }

    @FXML private void handleDashboard()     { chargerVue("Dashboard"); }
    @FXML private void handleCategories()    { chargerVue("Categorie"); }
    @FXML private void handleFournisseurs()  { chargerVue("Fournisseur"); }
    @FXML private void handleProduits()      { chargerVue("Produit"); }
    @FXML private void handleMouvements()    { chargerVue("Mouvement"); }
    @FXML private void handleUtilisateurs()  {
        if (!SessionManager.isAdmin()) {
            AlertUtil.showWarning("Accès refusé", "Cette section est réservée aux administrateurs.");
            return;
        }
        chargerVue("Utilisateur");
    }

    @FXML
    private void handleDeconnexion() {
        boolean confirm = AlertUtil.showConfirmation("Déconnexion",
                "Voulez-vous vraiment vous déconnecter ?");
        if (confirm) {
            SessionManager.logout();
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
                javafx.scene.Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("LAD Stock — Connexion");
                stage.setScene(new javafx.scene.Scene(root, 500, 600));
                stage.setResizable(false);
                stage.show();
                Stage current = (Stage) mainPane.getScene().getWindow();
                current.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleQuitter() {
        boolean confirm = AlertUtil.showConfirmation("Quitter", "Voulez-vous vraiment quitter LAD Stock ?");
        if (confirm) System.exit(0);
    }

    @FXML
    private void handleAPropos() {
        AlertUtil.showInfo("À propos de LAD Stock",
                "LAD Stock v1.0\n" +
                "Application de Gestion des Stocks\n\n" +
                "INP-HB — Département Informatique IC-GL\n" +
                "Année 2025-2026\n\n" +
                "Réalisé par :\n" +
                "• BROU AKANDA ASSI ARISTIDE\n" +
                "• LENAUD SOKONI NADIA\n" +
                "• DOUMBIA KARIDJATOU");
    }

    private void chargerVue(String nomFxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/" + nomFxml + ".fxml"));
            Node vue = loader.load();
            mainPane.setCenter(vue);
        } catch (IOException e) {
            AlertUtil.showError("Erreur de navigation", "Impossible de charger la vue : " + nomFxml);
            e.printStackTrace();
        }
    }
}

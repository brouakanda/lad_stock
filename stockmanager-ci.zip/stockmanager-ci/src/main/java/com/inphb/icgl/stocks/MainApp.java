package com.inphb.icgl.stocks;

import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * Point d'entree principal de l'application LAD Stock.
 * Auteur : BROU AKANDA ASSI ARISTIDE
 */
public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
        Parent loginRoot = loader.load();
        Stage loginStage = new Stage();
        loginStage.setTitle("LAD Stock - Connexion");
        loginStage.setScene(new Scene(loginRoot, 500, 600));
        loginStage.setResizable(false);
        loginStage.getIcons().add(new Image(getClass().getResourceAsStream("/images/logo.png")));

        SplashScreen splash = new SplashScreen();
        splash.showAndProceed(loginStage);
    }

    @Override
    public void stop() {
        DatabaseConnection.closeConnection();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

package com.inphb.icgl.stocks;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * Fenetre de demarrage animee (Splash Screen).
 * Auteur : LENAUD SOKONI NADIA
 */
public class SplashScreen extends Stage {

    public SplashScreen() throws Exception {
        initStyle(StageStyle.UNDECORATED);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/SplashScreen.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root, 680, 630);
        setScene(scene);
        getIcons().add(new Image(getClass().getResourceAsStream("/images/logo.png")));
        centerOnScreen();
    }

    /**
     * Affiche le splash 3 secondes puis ouvre la fenetre de connexion.
     */
    public void showAndProceed(Stage loginStage) {
        show();
        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> {
            Timeline fadeOut = new Timeline(
                new KeyFrame(Duration.millis(400),
                    new KeyValue(opacityProperty(), 0.0))
            );
            fadeOut.setOnFinished(evt -> {
                close();
                loginStage.show();
            });
            fadeOut.play();
        });
        pause.play();
    }
}

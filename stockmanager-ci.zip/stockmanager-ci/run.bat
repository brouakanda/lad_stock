@echo off
REM Script de lancement de StockManager CI
REM Ajoute automatiquement JavaFX 21 sur le module-path

SET M2=%USERPROFILE%\.m2\repository\org\openjfx
SET FX_PATH=%M2%\javafx-controls\21\javafx-controls-21-win.jar;%M2%\javafx-fxml\21\javafx-fxml-21-win.jar;%M2%\javafx-graphics\21\javafx-graphics-21-win.jar;%M2%\javafx-base\21\javafx-base-21-win.jar

echo Lancement de StockManager CI...
call mvn -f "%~dp0pom.xml" javafx:run

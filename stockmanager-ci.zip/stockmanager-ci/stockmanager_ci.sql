-- ══════════════════════════════════════════════════════════════
-- BASE DE DONNÉES : stockmanager_ci
-- Contexte : Commerce ivoirien / Afrique de l'Ouest
-- Projet INP-HB IC-GL 2025-2026
-- ══════════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS stockmanager_ci
    CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE stockmanager_ci;

-- ── TABLE 1 : utilisateurs ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom_complet VARCHAR(150) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(64) NOT NULL,
    role ENUM('ADMIN','GESTIONNAIRE') DEFAULT 'GESTIONNAIRE',
    actif TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── TABLE 2 : categories ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
);

-- ── TABLE 3 : fournisseurs ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS fournisseurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    telephone VARCHAR(20),
    email VARCHAR(100),
    adresse VARCHAR(255),
    ville VARCHAR(100)
);

-- ── TABLE 4 : produits ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS produits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference VARCHAR(30) NOT NULL UNIQUE,
    designation VARCHAR(200) NOT NULL,
    id_categorie INT,
    id_fournisseur INT,
    prix_unitaire DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    quantite_stock INT NOT NULL DEFAULT 0,
    stock_minimum INT NOT NULL DEFAULT 5,
    unite VARCHAR(30) DEFAULT 'pièce',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_categorie) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (id_fournisseur) REFERENCES fournisseurs(id) ON DELETE SET NULL
);

-- ── TABLE 5 : mouvements ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mouvements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_produit INT NOT NULL,
    type_mouvement ENUM('ENTREE','SORTIE') NOT NULL,
    quantite INT NOT NULL,
    motif VARCHAR(255),
    id_utilisateur INT,
    date_mouvement TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_produit) REFERENCES produits(id) ON DELETE CASCADE,
    FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id) ON DELETE SET NULL
);

-- ══════════════════════════════════════════════════════════════
-- DONNÉES INITIALES (contexte ivoirien)
-- ══════════════════════════════════════════════════════════════

INSERT INTO utilisateurs (nom_complet, login, mot_de_passe, role) VALUES
    ('Administrateur Système', 'atta', SHA2('admin123', 256), 'ADMIN'),
    ('BROU Aristide Gestionnaire', 'brou', SHA2('aristide2026', 256), 'GESTIONNAIRE'),
    ('LENAUD Nadia Responsable', 'lenaud', SHA2('nadia2026', 256), 'GESTIONNAIRE');

INSERT INTO categories (libelle, description) VALUES
    ('Alimentaire', 'Produits alimentaires et boissons'),
    ('Quincaillerie', 'Matériaux de construction et outils'),
    ('Papeterie', 'Fournitures scolaires et de bureau'),
    ('Électronique', 'Appareils et accessoires électroniques'),
    ('Médicament', 'Produits pharmaceutiques et hygiène'),
    ('Agro-alimentaire', 'Produits agricoles transformés'),
    ('Textile', 'Vêtements et tissus'),
    ('Matériaux', 'Matériaux de construction');

INSERT INTO fournisseurs (nom, telephone, email, adresse, ville) VALUES
    ('SIFCA Distribution', '27 20 25 00 00', 'contact@sifca.ci', 'Zone Industrielle de Vridi', 'Abidjan'),
    ('SIMAT Quincaillerie', '27 20 31 12 00', 'simat@simat.ci', 'Rue du Commerce, Adjamé', 'Abidjan'),
    ('CFAO Technologies', '27 21 00 11 00', 'cfao@cfao.ci', 'Avenue Chardy, Plateau', 'Abidjan'),
    ('Librairie de France CI', '27 20 22 50 00', 'ldf@librairie.ci', 'Bd Carde, Plateau', 'Abidjan'),
    ('COPHARMED', '27 20 37 40 00', 'copharmed@cop.ci', 'Zone 4, Marcory', 'Abidjan'),
    ('LAFARGE CI', '27 20 21 00 00', 'lafarge@lafarge.ci', 'Route d\'Anyama', 'Abidjan'),
    ('NESTLE CI', '27 20 30 15 00', 'nestle@nestle.ci', 'Zone Industrielle Yopougon', 'Abidjan'),
    ('BAMBA Agro', '05 06 70 80 90', 'bamba@agro.ci', 'Quartier Commerce', 'Korhogo');

INSERT INTO produits (reference, designation, id_categorie, id_fournisseur, prix_unitaire, quantite_stock, stock_minimum, unite) VALUES
    ('CIM-CPI-001', 'Ciment CPI 42.5 LAFARGE', 8, 6, 5500.00, 150, 20, 'Sac'),
    ('ALM-DIN-001', 'Huile Palme Dinor 5L', 1, 1, 3200.00, 80, 15, 'Bidon'),
    ('PAP-BIC-001', 'Stylo Bic Cristal (boîte 50)', 3, 4, 2500.00, 45, 10, 'Boîte'),
    ('MED-PAR-001', 'Paracétamol 500mg (boîte 100cp)', 5, 5, 1500.00, 3, 10, 'Boîte'),
    ('QUI-TOL-001', 'Tôle ondulée 3m galvanisée', 2, 2, 8500.00, 200, 30, 'Pièce'),
    ('ALM-RIZ-001', 'Riz parfumé 25kg Thaïlande', 1, 1, 18000.00, 4, 20, 'Sac'),
    ('ELC-AMP-001', 'Ampoule LED 15W E27', 4, 3, 1200.00, 60, 20, 'Pièce'),
    ('MED-ART-001', 'Artemether 80mg (boîte)', 5, 5, 3500.00, 2, 5, 'Boîte'),
    ('PAP-CAH-001', 'Cahier 200 pages grand format', 3, 4, 800.00, 120, 30, 'Pièce'),
    ('QUI-CIM-002', 'Sable fin pour construction (sac)', 2, 2, 1200.00, 300, 50, 'Sac'),
    ('ALM-SUC-001', 'Sucre cristallisé 50kg', 6, 7, 28000.00, 25, 10, 'Sac'),
    ('ELC-CAB-001', 'Câble électrique 1.5mm (100m)', 4, 3, 45000.00, 8, 3, 'Rouleau');

INSERT INTO mouvements (id_produit, type_mouvement, quantite, motif, id_utilisateur) VALUES
    (1, 'ENTREE', 100, 'Approvisionnement initial', 1),
    (2, 'ENTREE', 50, 'Approvisionnement initial', 1),
    (3, 'ENTREE', 30, 'Approvisionnement initial', 1),
    (4, 'ENTREE', 15, 'Approvisionnement initial', 1),
    (4, 'SORTIE', 12, 'Vente client', 2),
    (5, 'ENTREE', 200, 'Approvisionnement initial', 1),
    (6, 'ENTREE', 30, 'Approvisionnement initial', 1),
    (6, 'SORTIE', 26, 'Vente en gros DIALLO', 2),
    (7, 'ENTREE', 60, 'Approvisionnement initial', 1),
    (8, 'ENTREE', 10, 'Approvisionnement initial', 1),
    (8, 'SORTIE', 8, 'Vente pharmacie', 2),
    (11, 'ENTREE', 25, 'Approvisionnement initial', 1);
